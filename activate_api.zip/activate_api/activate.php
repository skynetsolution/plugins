<?php

	/* 
    Designed By Pejonic
    Author: John Sage Nwanosike
    Email: sage@pejonic.com or pejonic@gmail.com
    Plugin index controller
  */

  
  define('YOUR_SPECIAL_SECRET_KEY', '5a21c669ca0eb0.41896980'); //Rename this constant name so it is specific to your plugin or theme.

  // This is the URL where API query request will be sent to. This should be the URL of the site where you have installed the main license manager plugin. Get this value from the integration help page.
  define('YOUR_LICENSE_SERVER_URL', 'http://imgeneral.org'); //Rename this constant name so it is specific to 

  define('YOUR_ITEM_REFERENCE', 'ultimate_video_locker_pro'); 

  class amakeAvailable
  {
  	public $api_key = null;
  	public $post = "http://imgeneral.org";
  	public $secretKey = "5a21c669ca0df9.06309910";

  	public function __construct($api_key)
  	{
  		$this->api_key = $api_key;

  		
  	}

  	public function get_api(){

     
     global $wpdb;
     $table_db_name = $wpdb->prefix . "ultimate_video_locker_pro";
     $query = "
     (SELECT * FROM $table_db_name )
      ";

  		/*** License activate button was clicked ***/
  	
  		if (!empty($this->api_key)) {
  		    

  		    // API query parameters
  		    $api_params = array(
  		        'slm_action' => 'slm_check',
  		        'secret_key' => YOUR_SPECIAL_SECRET_KEY,
  		        'license_key' => $this->api_key, 
  		    );
 
							
  		    // Send query to the license manager server 
			$response = wp_remote_get(add_query_arg($api_params, YOUR_LICENSE_SERVER_URL), array('timeout' => 20, 'sslverify' => false));
			
  		    // Check for error in the response
  		    if (is_wp_error($response)){
  		        echo "Unexpected Error! The query returned with an error.";
  		    }


  		    
  		    
  		    // License data.
  		    $license_data = json_decode(wp_remote_retrieve_body($response));
  		    
  		    // TODO - Do something with it.
  		    // var_dump($response);//uncomment it to look at the data
  		    
  		    if($license_data->result == 'success'){//Success was returned for the license activation
  		        
  		        //Uncomment the followng line to see the message that returned from the license server
  		        echo '<div class="alert alert-success" style="backgroud:green; padding:10px; text-align:center">'.'<br />The following message was returned from the server: '.$license_data->message.'</div>';
  		        
				update_option('license_key', $this->api_key);
  		        update_option('s872_uvlp_pejonic', true);

  		    }
  		    else{
  		        //Show error to the user. Probably entered incorrect license key.
  		        
  		        //Uncomment the followng line to see the message that returned from the license server
  		        echo '<div style="backgroud:red; padding:10px; text-align:center"><br />The following message was returned from the server: '.$license_data->message.'</div>';
  		    };
  		
  		///return var_dump($response);//uncomment it if you want to look at the full response
  		


  	}



  }
 }