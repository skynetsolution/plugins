<?php


// SETTING UP THE PLUGIN MENU...

add_action('admin_menu', 'ultimate_video_locker_pro_admin_menu');



function ultimate_video_locker_pro_admin_menu() 
{
	$pluginName = "ultimate_video_locker_pro";
	add_menu_page('ULTIMATE VIDEO LOCKER PRO! Video Player', 'ULTIMATE VIDEO LOCKER PRO!', 'manage_options', $pluginName . '-dashboard', $pluginName . '_dashboard', plugin_dir_url($v).'/ultimate_video_locker_pro/images/icon.png');	
}

?>