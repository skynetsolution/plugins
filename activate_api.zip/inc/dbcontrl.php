<?php

add_option( "dfxx_db_version"); // Core DB Version Option
update_option( "dfxx_db_version", "ultimate_video_locker_pro"); // Current DB Version

add_option( "dfxx_db_lead_version"); // Leads DB Version Option
update_option( "dfxx_db_lead_version", "ultimate_video_locker_pro_leads"); // Current DB Version

?>