$(function(){
	
	$('body').find('.submit .button').on('click', function(e){
		e.preventDefault();
	
	});




});