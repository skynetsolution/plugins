<?php

/**
* Designed By Pejonic
*/

require('../../../../../wp-load.php');
require('MailChimp.php');
require('Webhook.php');
require('Batch.php');
use \DrewM\MailChimp\MailChimp;



class mail_api_controller
{
	public $apiKey = "";
	public $listId = "";
	public $message = "";
	function __construct($value)
	{
			$this->listId = $value->mailuserid;
			$this->apiKey = $value->mailapikey;
			$this->message = $value->mailapisuccess;
			
	}


	public function syncMailchimp($data) {
	    
	    $MailChimp = new MailChimp($this->apiKey);
	    $result = $MailChimp->get('lists');
		
		// Adding list id to thise line via the database table
		$result = $MailChimp->post("lists/$this->listId/members", [
						'email_address' => $data['data']['email'],
						'status'        => 'subscribed',
						'merge_fields' => ['FNAME' => $data['data']['name']]
					]);

			   $message  = '';
	          
	           if($result['title'] !== 'Invalid Resource'){
	           	$message =  json_encode(['message' => true, 'mgs_text' => $this->message]);
	           }
	           else{
	           	$message = json_encode(['message' => false]);
	           }
	        
	    return $message;

	   
	}

	public function clicked(){
		$data = $_REQUEST;

		$id = $_GET['edit'];
		$clicks = get_option('clicks'.'_'.$id) + 1; 
		update_option('clicks'.'_'.$id, $clicks, ENT_NOQUOTES, "iso-8859-1"); 
		
	}


}