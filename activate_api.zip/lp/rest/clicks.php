<?php 
	define('WP_USE_THEMES', false);
	require('../../../../../wp-load.php');

	require('/mail_api/mail_api_controller.php');
	$rest = $_REQUEST['data'];
	$id = $_GET['edit'];
	$clicks = get_option('clicks'.'_'.$id) + 1; 
	update_option('clicks'.'_'.$id, $clicks, ENT_NOQUOTES, "iso-8859-1"); 

	$results = get_option('ultimate_video_locker_pro_campaign_'. $rest['id']);

	$api = new mail_api_controller($results);

	echo $api->syncMailchimp($_REQUEST);
	
 ?>