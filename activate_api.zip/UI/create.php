<div id="listapps">
	<div id="appHeader">
		<span>Create a New  Page:</span>
	</div>
	<div id="formArea" style="padding:20px; ">
		<h3>Page Name: <span style="font-weight:normal;">Give your new page a name...</span> <span id="notice_name" style="color:red; display:none;"><b>* Need a name!</b></span></h3>
		<input class="inputField" type="text" name="appname" id="appname" value="">
	</div>
	<div class="appnew" style="margin-top: -20px;" >
		<span class="saved btn" style="width: 100px; text-align: center" id="createnewapp" ><a href="#">Create New Page</a></span>
		<br clear="right" > <br>
	</div>
</div>
