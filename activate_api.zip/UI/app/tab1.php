<div class="tabber" id="tab1">
	<div class="titleBar">
		<i class="fa fa-dashboard" style="float: right; font-size: 55px; padding: 10px 10px"></i>
		<h2><strong>Dashboard</strong></h2>
		<p>Watch Video How to Setup ultimate_video_locker_pro</p>
	</div>
	<div class="dash" style="padding: 10px 20px;">
		<br>
		<iframe width="560" height="515" style="width: 100%" src="http://www.youtube.com/embed/0kBtPi2QvNA?enablejsapi=1&html5=1&controls=1&rel=0&title=0&showinfo=0&iv_load_policy=3&hd=1&vq=hd720" frameborder="0" allowfullscreen></iframe>
	</div>
	<?php 
	// Add Your Inputs
	?>
</div>