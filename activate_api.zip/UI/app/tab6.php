<div class="tabber" id="tab6" style="display: none;">
	<div class="titleBar">
		<i class="fa fa-gear" style="float: right; font-size: 55px; padding: 10px 10px"></i>
		<h2><strong>Embed Code</strong></h2>
		<p>Add Shortcode to your blog or copy the HTML code.</p>
	</div>
	<h3>Shortcode for Posts / Pages</h3>
	<textarea style="width: 100%; padding: 10px; height: 50px;">[ultimate_video_locker_pro id="<?= $_GET['id'] ?>"]</textarea>
	
</div>