<div id="listapps">

	<style type="text/css">
		.inline{
			width: 30%;
			display: inline-block;
		}
		.k_d{
			width: 50%;
		}
	</style>
	<?php  require(WP_PLUGIN_DIR.'/ultimate_video_locker_pro/activate_api/activate.php'); 

		global $wpdb;
		$table_db_name = $wpdb->prefix . "ultimate_video_locker_pro";
		$query = "
		(SELECT * FROM $table_db_name )
			";
		$results = $wpdb->get_results($query, OBJECT);


		$get = new amakeAvailable($_REQUEST['k_d']);
		$array = [];
		 $data = $get->get_api();

		 $rules = get_option('s872_uvlp_pejonic');
		
echo '<pre>';
print_r($rules);
echo '</pre>';

		

	?>
 <?php if($rules == true): ?>

	<div id="appHeader">
		<span><i class="fa fa-cog"></i> Preview, Edit and Update Your Pages:</span>
	</div>
	<?php 
		// Display Apps:
		
		foreach($results as $results) {
	?>
	<div class="appitem">
		<div class="appinfo appinside">
			<span class="appTitle"><?php echo stripcslashes($results->appname); ?> <?= get_option('license_key') ?></span>
			<span class="appMeta"><b><i class="fa fa-calendar-o"></i> Created:</b> <?php echo stripcslashes($results->created); ?> - <a href="<?php echo  $sitePath."/lp/index.php?id=".$results->ID."&p=".$results->ID; ?>"  class="preview" target="_blank" style="display: inline !important; float: none; padding-left: 10px; text-decoration: none"><i class="fa fa-search"></i> Preview Your Page</a></span>
		</div>
		<div class="appedit">
			<span class="grey-btn btn" ><a href="<?php echo $_SERVER["REQUEST_URI"]; ?>&id=<?php echo stripcslashes($results->ID); ?>">edit</a></span>
		</div>
		<br clear="left">
	</div>
	<?php
	}
	?>

	
	<div class="appnew">
		<div class="grey-btn btn" style="width: 100px; text-align: center" ><a href="<?php echo site_url(); ?>/wp-admin?page=ultimate_video_locker_pro-dashboard&create">Create New</a></div>	
		<br clear="right" >
	</div>

  <?php else: ?>
  	<div id="appHeader">
		<span>Activate Ultimate Video Locker Pro</span>
	</div>

	<div class="appitem">
		<div class="">
			<form action="" method="post">
				
       			<div class="k_d">
       				<label>Enter Activation Code</label>
				<input type="text" name="k_d" class="inputField elem" value="<?= get_option('license_key') ?>" placeholder="Enter Activation Code" >
				<a href="http://wpcontentlocker.imgeneral.org/" target="_blank">Click here to get license key</a>
			    </div>

				<input type="submit" value="Activate" class="btn btn-primary blue-btn">
				
			</form>
		</div>
		
		
	</div>

  <?php endif; ?>



</div>

