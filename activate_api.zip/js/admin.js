jQuery(document).ready(function(){
		
	jQuery("#remove_domain").click( function(event)
           
		event.preventDefault();
		alert('Please Enter date in formate mm/dd/yyyy');
		return false;
					
	);
		
	
});

