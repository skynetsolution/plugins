
function getRSS() {
    jQuery.ajax({
        url: document.location.protocol + '//ajax.googleapis.com/ajax/services/feed/load?v=1.0&num=10&callback=?&q=' + encodeURIComponent('http://www.pluginresults.com/feed'),
        dataType: 'json',
        success: function(data) {
      
            // Get the entries
            entries = data.responseData.feed.entries;
      
            // Build the output
            output = "<ul>";
            jQuery.each(entries, function (index, value) {
                console.log(value);
                entry = value;
                title = entry.title;
                content = entry.content;
                link = entry.link;
                
                // Work out the published date
                var date =  new Date(entry.publishedDate);
                var months = Array("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December");
                var datestring = months[date.getMonth()] + " " + date.getDate() + " " + date.getFullYear() 
                
                snippet = entry.contentSnippet;
                
                output += '<li><a class="rsswidget" title="' + title + '" href="' + link + '">' + title + '</a> ';
                output += '<span class="rss-date">' + datestring + '</span>';
                output += '<div class="rssSummary">' + snippet + ' [...]</div>';
                
                output += '</li>';
            });
            output += '</ul>';
            jQuery('#rsswidget').html(output);
        }
    });
}
getRSS();